package com.example.travelmaker.tourinfo.network;

import java.util.*;

import com.example.travelmaker.info.data.*;


public interface FeedParser3 {

	COMNTourData parse3() throws Exception;
}
