package com.example.travelmaker.tourinfo.network;

import java.util.*;

public interface FeedParser4 {

	ArrayList<String> parse4() throws Exception;
}
